<?php

class Philwinkle_Fixerio_Model_Observer
{


}

