Manage Stock in Magento by Store
=================================

This small extension lets you set the inventory settings in the backend
on a store level or website level (not global!) basis.

Your mileage may vary but it has worked well for the cases its been used in.

Currently supported per store is backorders, qty increments, max sale qty,
min sale qty, enable / disable qty increments and the manage stock setting.


Disclaimer
-------

Provided as-is and free for personal and commercial usage. 
No warranty provided - use at your own risk
