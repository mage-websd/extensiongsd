<?php
    class Bc_Deliverydate_Block_Email_Info extends Mage_Sales_Block_Items_Abstract
    {
        
    }
?>