<?php

class MW_Ddate_Block_Adminhtml_Sales_Order_Create_Ddate extends Mage_Adminhtml_Block_Widget_Grid
{
    public function __construct()
    {
        parent::__construct();
    }
}
