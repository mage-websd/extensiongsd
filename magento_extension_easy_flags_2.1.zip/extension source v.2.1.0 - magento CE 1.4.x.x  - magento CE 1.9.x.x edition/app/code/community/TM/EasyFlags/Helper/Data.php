<?php

class TM_EasyFlags_Helper_Data extends Mage_Core_Helper_Abstract
{
    
}