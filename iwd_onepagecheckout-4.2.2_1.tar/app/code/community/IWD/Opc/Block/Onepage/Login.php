<?php
class IWD_Opc_Block_Onepage_Login extends Mage_Customer_Block_Form_Login{
	
}