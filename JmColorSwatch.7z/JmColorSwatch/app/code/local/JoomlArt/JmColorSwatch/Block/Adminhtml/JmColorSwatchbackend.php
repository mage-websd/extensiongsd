<?php  

class JoomlArt_JmColorSwatch_Block_Adminhtml_JmColorSwatchbackend extends Mage_Adminhtml_Block_Template {

}