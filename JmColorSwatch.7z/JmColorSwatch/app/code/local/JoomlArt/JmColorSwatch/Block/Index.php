<?php   
class JoomlArt_JmProductDetail_Block_Index extends Mage_Core_Block_Template{   





}