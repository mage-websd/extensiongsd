<?php 
/**
 ::[Header]::
 */

//require_once 'Customweb/Mvc/Controller/AbstractAdapter.php';
//require_once 'Customweb/Payment/Endpoint/IAdapter.php';


/**
 * @author Thomas Hunziker
 *
 */
abstract class Customweb_Payment_Endpoint_AbstractAdapter extends Customweb_Mvc_Controller_AbstractAdapter implements Customweb_Payment_Endpoint_IAdapter {
	
		
}