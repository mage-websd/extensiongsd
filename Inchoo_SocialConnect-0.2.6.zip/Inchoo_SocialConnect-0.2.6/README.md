Inchoo_SocialConnect
====================

Inchoo_SocialConnect is a Magento extension allowing your customers to login or create an account at your store using their Google, Facebook or Twitter account.

For usage instructions and more details you can visit my [article at inchoo.net](http://inchoo.net/ecommerce/magento/social-connect-magento-extension/).
